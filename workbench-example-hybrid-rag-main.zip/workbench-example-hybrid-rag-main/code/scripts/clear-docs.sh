# This script empties the vector database of all uploaded documents. 

python /project/code/scripts/helpers/empty-docs.py &
sleep 3
exit 0