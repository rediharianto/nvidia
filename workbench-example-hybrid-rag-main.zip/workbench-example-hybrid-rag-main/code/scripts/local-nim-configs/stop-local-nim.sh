# This script stops the NVIDIA Inference Microservice container locally on DOCKER-enabled systems. 

docker stop local_nim

sleep 1
exit 0
