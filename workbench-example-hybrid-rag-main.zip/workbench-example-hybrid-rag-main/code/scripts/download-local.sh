# This script downloads the weights for a user-selected model. This may take a few minutes to run. 

text-generation-server download-weights $1

sleep 2
exit 0