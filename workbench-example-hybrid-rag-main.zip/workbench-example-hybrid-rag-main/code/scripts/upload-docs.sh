# This script uploads documents to the vector database. 

python /project/code/scripts/helpers/upload-docs.py 
exit 0